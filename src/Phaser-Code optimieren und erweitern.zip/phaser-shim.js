// Shim: repo-style `import Phaser from 'phaser'` backed by the UMD global.
export default window.Phaser;
