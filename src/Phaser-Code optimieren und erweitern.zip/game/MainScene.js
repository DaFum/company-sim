import Phaser from 'phaser';
import { useGameStore, actions } from './simStore.js';
import Pathfinder from './pathfinding.js';
import SoundManager from './SoundManager.js';
import WorkerSprite from './WorkerSprite.js';
import { ROLE_PARTICLES } from './palette.js';

const DRAG_FRICTION = 0.95;
const ZOOM_SENSITIVITY = 0.002;
const MIN_INERTIA_VELOCITY_SQ = 0.1;
const LIGHT_BUDGET = 6; // Max simultaneous worker PointLights (cheap fake lights)

/**
 * Optimized MainScene:
 * - Pathfinding grid is DERIVED from the actually spawned furniture (blockers
 *   registered in spawnObject) — no more hardcoded 3-tile obstacle list.
 * - Depth sorting moved into sprites (only on y-change); no per-frame iterate.
 * - Shared per-role particle emitters; worker light budget.
 * - EasyStar replaced by a zero-dep A* with per-frame request budget.
 * - Extended: desk assignment, standup meetings, watercooler chats, couch
 *   breaks, new chaos events (PIZZA_PARTY, POWER_SURGE), simulated AI director,
 *   in-canvas HUD (day/mood/staff/FPS, hire/fire, mute).
 */
export default class MainScene extends Phaser.Scene {
  constructor() {
    super({ key: 'MainScene' });
    this.unsubscribers = [];
    this._chaosTweens = [];
    this._officeAssetKeys = new Set();
    this._lightCount = 0;
  }

  create() {
    this._officeAssetKeys.clear();
    this._lightCount = 0;
    this.soundManager = new SoundManager(this);

    if (!this.anims.exists('coffee_drain')) {
      this.anims.create({
        key: 'coffee_drain',
        frames: this.anims.generateFrameNumbers('obj_coffee_anim', { start: 0, end: 2 }),
        frameRate: 0.5,
        repeat: 0,
      });
      this.anims.create({
        key: 'coffee_refill',
        frames: this.anims.generateFrameNumbers('obj_coffee_anim', { frames: [3, 0] }),
        frameRate: 2,
        repeat: 0,
      });
    }

    this.floorTexture = null;
    this.objectGroup = this.add.group();
    this.workersGroup = this.add.group({ runChildUpdate: true });
    this.visitorGroup = this.add.group({ runChildUpdate: true });
    this.overlayGroup = this.add.group();

    // Shared per-role emitters (perf: was one emitter per worker)
    this.roleEmitters = {};
    for (const role of ['dev', 'sales', 'support']) {
      this.roleEmitters[role] = this.add.particles(0, 0, 'particle_pixel', {
        speed: { min: 50, max: 100 },
        angle: { min: 220, max: 320 },
        scale: { start: 0.6, end: 0 },
        alpha: { start: 1, end: 0 },
        gravityY: 100,
        lifespan: 600,
        tint: ROLE_PARTICLES[role],
        emitting: false,
      }).setDepth(95);
    }

    this.setupGrid();
    this.createFloor(1);
    this.blockers = [];
    this.desks = [];
    this.coffeeTile = { x: 23, y: 16 }; // walkable tile next to the machine
    this.breakSpots = [{ x: 11, y: 15 }, { x: 13, y: 15 }, { x: 12, y: 15 }];
    this.chatSpots = [{ x: 19, y: 16 }, { x: 20, y: 16 }];
    this.spawnObjects();
    this.createWalls();
    this.applyObstaclesToGrid();

    this.cameras.main.centerOn(400, 300);
    this.cameras.main.setBackgroundColor('#0d0f18');

    this.input.addPointer(1);
    this.setupCameraControls();
    this.setupTouchInteractions();
    this.pinchDistance = 0;
    this.isDragging = false;
    this.dragLastPosition = new Phaser.Math.Vector2();
    this.dragVelocity = new Phaser.Math.Vector2(0, 0);
    this.dragFriction = DRAG_FRICTION;

    this.setupTooltip();
    this.setupDayNightCycle();
    this.setupHud();

    // Lighting: Light2D pipeline + postFX removed (perf) — PointLights only.
    this.mouseLight = this.add.pointlight(0, 0, 0xffffff, 180, 0.12).setDepth(850);
    this._onPointerMove = (pointer) => {
      if (this.mouseLight) {
        this.mouseLight.x = pointer.worldX;
        this.mouseLight.y = pointer.worldY;
      }
    };
    this.input.on('pointermove', this._onPointerMove);

    // Store subscriptions (same shape as repo)
    const store = useGameStore;
    this.unsubscribers.push(
      store.subscribe((s) => s.employees, (e) => this.syncEmployees(e)),
      store.subscribe((s) => s.activeVisitors, (v) => this.syncVisitors(v)),
      store.subscribe((s) => s.mood, (m) => this.updateMoodVisuals(m)),
      store.subscribe((s) => s.activeEvents, (e) => this.syncChaosVisuals(e)),
      store.subscribe((s) => s.tick, (t) => this.updateDayNight(t)),
      store.subscribe((s) => s.inventory, (i) => this.syncInventoryVisuals(i)),
      store.subscribe((s) => s.decisionHistory, (h) => this.syncDecisionOfficeAssets(h)),
      store.subscribe((s) => s.lastDirectorMsg, (m) => this.setTicker(m))
    );

    // Seed team
    const st = store.getState();
    if (st.employees.length === 0) {
      actions.hire('dev', 'NORMAL'); actions.hire('dev', '10x_ENGINEER');
      actions.hire('dev', 'JUNIOR'); actions.hire('dev', 'NORMAL');
      actions.hire('sales', 'NORMAL'); actions.hire('sales', 'NORMAL');
      actions.hire('support', 'NORMAL'); actions.hire('support', 'TOXIC');
    } else {
      this.syncEmployees(st.employees);
    }
    this.syncVisitors(st.activeVisitors);
    this.updateMoodVisuals(st.mood);
    this.syncChaosVisuals(st.activeEvents);
    this.syncInventoryVisuals(st.inventory);
    this.syncDecisionOfficeAssets(st.decisionHistory);

    // Simulation clocks
    this._timers = [
      this.time.addEvent({ delay: 250, loop: true, callback: () => actions.advanceTick() }),
      this.time.addEvent({ delay: 12000, loop: true, callback: () => this.directorDecision() }),
      this.time.addEvent({ delay: 45000, loop: true, callback: () => this.startMeeting() }),
      this.time.addEvent({ delay: 28000, loop: true, callback: () => this.startChat() }),
    ];

    this._onZoomIn = () => this.handleZoom(0.2);
    this._onZoomOut = () => this.handleZoom(-0.2);
    window.addEventListener('ZOOM_IN', this._onZoomIn);
    window.addEventListener('ZOOM_OUT', this._onZoomOut);

    this.events.once(Phaser.Scenes.Events.SHUTDOWN, this.onShutdown, this);
  }

  update() {
    this.pathfinder?.update();
    this.handleMobileControls();
    if (this.fpsText && this.game.loop.frame % 30 === 0) {
      this.fpsText.setText(`FPS ${Math.round(this.game.loop.actualFps)}`);
    }
  }

  // --- LIGHT BUDGET ---
  requestLight() {
    if (this._lightCount < LIGHT_BUDGET) { this._lightCount++; return true; }
    return false;
  }
  releaseLight() { this._lightCount = Math.max(0, this._lightCount - 1); }

  // --- HUD (in-canvas, scrollFactor 0) ---
  setupHud() {
    const mk = (x, y, str, size = 12) =>
      this.add.text(x, y, str, {
        fontSize: `${size}px`,
        fontFamily: 'Courier New',
        color: '#ffb000',
        backgroundColor: '#10131dcc',
        padding: { x: 6, y: 4 },
      }).setScrollFactor(0).setDepth(1000);

    this.statusText = mk(8, 8, '');
    this.fpsText = mk(8, 34, 'FPS --');
    this.tickerText = mk(8, this.scale.height - 28, '> AI director online.', 11).setColor('#9be7ff');

    const btn = (x, label, cb) => {
      const b = mk(x, this.scale.height - 62, label, 13).setInteractive({ useHandCursor: true });
      b.on('pointerup', () => { cb(); this.soundManager.play('pop'); });
      b.on('pointerover', () => b.setColor('#ffffff'));
      b.on('pointerout', () => b.setColor('#ffb000'));
      return b;
    };
    btn(8, '+DEV', () => actions.hire('dev'));
    btn(70, '+SALES', () => actions.hire('sales'));
    btn(152, '+SUPP', () => actions.hire('support'));
    btn(226, '-FIRE', () => actions.fireRandom());
    btn(294, '♪', () => {
      this.soundManager.setMute(!this.soundManager.isMuted);
    });

    // Fullscreen (kept from repo)
    const fs = this.add.text(this.scale.width - 40, 40, '⛶', {
      fontSize: '32px', backgroundColor: '#00000055', padding: { x: 5, y: 5 },
    }).setOrigin(1, 0).setScrollFactor(0).setDepth(1000).setInteractive();
    fs.on('pointerup', () => {
      if (this.scale.isFullscreen) this.scale.stopFullscreen();
      else this.scale.startFullscreen();
    });

    this.time.addEvent({ delay: 250, loop: true, callback: () => this.refreshHud() });
  }

  refreshHud() {
    const s = useGameStore.getState();
    const hour = 9 + Math.floor((s.tick / 60) * 9);
    this.statusText?.setText(
      `DAY ${s.day} · ${String(hour).padStart(2, '0')}:00 · MOOD ${Math.round(s.mood)}% · STAFF ${s.employees.length}`
    );
  }

  setTicker(msg) {
    this.tickerText?.setText(`> ${msg}`);
  }

  // --- SIMULATED AI DIRECTOR ---
  directorDecision() {
    const s = useGameStore.getState();
    const roll = Math.random();
    if (roll < 0.3) {
      const role = Phaser.Math.RND.pick(['dev', 'sales', 'support']);
      const e = actions.hire(role);
      actions.setDirectorMsg(`Director hires a ${role.toUpperCase()} (${e.trait}).`);
    } else if (roll < 0.55) {
      const ev = Phaser.Math.RND.pick([
        ['TECH_OUTAGE', 'Servers are down!'],
        ['RANSOMWARE', 'Ransomware detected!'],
        ['MARKET_SHITSTORM', 'Social media firestorm!'],
        ['COMPETITOR_CLONE', 'A competitor cloned the product.'],
        ['PIZZA_PARTY', 'Director orders pizza for everyone!'],
        ['POWER_SURGE', 'Power grid is unstable.'],
        ['INVESTOR_VISIT', 'Investors drop by unannounced.'],
      ]);
      actions.startEvent(ev[0], ev[1], Phaser.Math.Between(15, 30));
      if (ev[0] === 'PIZZA_PARTY') actions.addVisitor('pizza_guy');
      if (ev[0] === 'INVESTOR_VISIT') actions.addVisitor('investors');
      actions.setDirectorMsg(`EVENT: ${ev[1]}`);
    } else if (roll < 0.75) {
      const owned = new Set(s.inventory);
      const upgrade = ['firewall', 'server_rack_v2', 'plants', 'coffee_machine', 'war_room', 'brand_studio', 'wellness_pod']
        .find((u) => !owned.has(u));
      if (upgrade) {
        actions.addInventory(upgrade);
        actions.setDirectorMsg(`Director buys upgrade: ${upgrade.replace(/_/g, ' ').toUpperCase()}.`);
      } else {
        actions.nudgeMood(4);
        actions.setDirectorMsg('Director praises the team. Mood up.');
      }
    } else if (roll < 0.9) {
      const done = new Set(s.decisionHistory.map((d) => d.action));
      const act = ['FUNDRAISE', 'CUSTOMER_RESEARCH', 'INCIDENT_DRILL', 'MARKETING_PUSH']
        .find((a) => !done.has(a));
      if (act) {
        actions.recordDecision(act);
        actions.setDirectorMsg(`Director executes: ${act.replace(/_/g, ' ')}.`);
      } else {
        actions.setDirectorMsg('Director reviews the KPIs. Nothing to do.');
      }
    } else {
      actions.setDirectorMsg('Director is thinking...');
    }
  }

  // --- SOCIAL BEHAVIORS ---
  startMeeting() {
    if (this._meetingActive) return;
    const seats = [{ x: 18, y: 3 }, { x: 19, y: 3 }, { x: 18, y: 5 }, { x: 19, y: 5 }];
    const cands = this.workersGroup.getChildren()
      .filter((w) => ['IDLE', 'MOVING'].includes(w.currentState))
      .slice(0, seats.length);
    if (cands.length < 2) return;
    this._meetingActive = true;
    cands.forEach((w, i) => {
      w.releaseDesk();
      w.goTo(seats[i].x, seats[i].y, 'MEETING');
    });
    this.setTicker('STANDUP: team gathers in the meeting room.');
    this.time.delayedCall(15000, () => {
      this._meetingActive = false;
      this.workersGroup.getChildren().forEach((w) => w.endMeeting?.());
    });
  }

  startChat() {
    const idle = this.workersGroup.getChildren().filter((w) => w.currentState === 'IDLE');
    if (idle.length < 2) return;
    const [a, b] = Phaser.Utils.Array.Shuffle(idle.slice()).slice(0, 2);
    a.goTo(this.chatSpots[0].x, this.chatSpots[0].y, 'CHAT');
    b.goTo(this.chatSpots[1].x, this.chatSpots[1].y, 'CHAT');
  }

  getBreakSpot() {
    return Phaser.Math.RND.pick(this.breakSpots);
  }

  claimDesk(worker) {
    const zone = worker.role === 'dev' ? 'dev' : 'sales';
    const free = this.desks.filter((d) => d.zone === zone && !d.claimedBy);
    if (!free.length) return null;
    const desk = Phaser.Math.RND.pick(free);
    desk.claimedBy = worker.id;
    return desk;
  }

  // --- CAMERA & INPUT (kept from repo) ---
  setupCameraControls() {
    this.input.on('wheel', (pointer, gameObjects, deltaX, deltaY) => {
      const newZoom = this.cameras.main.zoom - deltaY * 0.001;
      this.cameras.main.setZoom(Phaser.Math.Clamp(newZoom, 0.5, 3));
    });
  }

  handleZoom(delta) {
    this.cameras.main.setZoom(Phaser.Math.Clamp(this.cameras.main.zoom + delta, 0.5, 3));
  }

  handleMobileControls() {
    const input = this.input;
    const camera = this.cameras.main;
    const pointer1 = input.pointer1;
    const pointer2 = input.pointer2;

    if (pointer1.isDown && pointer2.isDown) {
      this.isDragging = false;
      this.dragVelocity.reset();
      const dist = Phaser.Math.Distance.Between(pointer1.x, pointer1.y, pointer2.x, pointer2.y);
      const midX = (pointer1.x + pointer2.x) / 2;
      const midY = (pointer1.y + pointer2.y) / 2;

      if (this.pinchDistance > 0) {
        const delta = dist - this.pinchDistance;
        const zoomFactor = delta * ZOOM_SENSITIVITY * camera.zoom;
        const newZoom = Phaser.Math.Clamp(camera.zoom + zoomFactor, 0.5, 3);
        if (newZoom !== camera.zoom) {
          const before = camera.getWorldPoint(midX, midY);
          camera.setZoom(newZoom);
          camera.preRender();
          const after = camera.getWorldPoint(midX, midY);
          camera.scrollX += before.x - after.x;
          camera.scrollY += before.y - after.y;
        }
      }
      this.pinchDistance = dist;
      return;
    } else {
      this.pinchDistance = 0;
    }

    const activePointer = input.activePointer;
    if (activePointer.isDown) {
      // Don't pan when starting on HUD buttons
      if (this.isDragging) {
        const dx = (activePointer.x - this.dragLastPosition.x) / camera.zoom;
        const dy = (activePointer.y - this.dragLastPosition.y) / camera.zoom;
        camera.scrollX -= dx;
        camera.scrollY -= dy;
        this.dragVelocity.set(-dx, -dy);
      } else {
        this.isDragging = true;
        this.dragVelocity.reset();
      }
      this.dragLastPosition.set(activePointer.x, activePointer.y);
    } else {
      this.isDragging = false;
      if (this.dragVelocity.lengthSq() > MIN_INERTIA_VELOCITY_SQ) {
        camera.scrollX += this.dragVelocity.x;
        camera.scrollY += this.dragVelocity.y;
        this.dragVelocity.scale(this.dragFriction);
        if (this.dragVelocity.lengthSq() < MIN_INERTIA_VELOCITY_SQ) this.dragVelocity.reset();
      }
    }
  }

  setupTouchInteractions() {
    this.input.on('pointerup', (pointer) => {
      if (pointer.getDistance() < 10) {
        const worldPoint = pointer.positionToCamera(this.cameras.main);
        const workers = this.workersGroup.getChildren();
        const clickedWorker = workers.find((w) =>
          w.getBounds().contains(worldPoint.x, worldPoint.y)
        );
        if (clickedWorker) {
          this.showTooltip(
            clickedWorker.x,
            clickedWorker.y - 40,
            `${clickedWorker.role.toUpperCase()}\nEnergy: ${Math.max(0, clickedWorker.energy).toFixed(0)}%`
          );
        } else {
          this.hideTooltip();
        }
      }
    });
  }

  // --- VISUALS: PARTICLES ---
  createSmoke(x, y) {
    const emitter = this.add.particles(x, y, 'particle_pixel', {
      speed: { min: 10, max: 30 },
      angle: { min: 240, max: 300 },
      scale: { start: 1, end: 3 },
      alpha: { start: 0.5, end: 0 },
      lifespan: 1000,
      frequency: 100,
      tint: 0x555555,
    });
    emitter.setDepth(50);
    this.time.delayedCall(2000, () => emitter.destroy());
  }

  createCodeBits(x, y) {
    const emitter = this.add.particles(x, y, 'particle_pixel', {
      speed: { min: 5, max: 15 },
      angle: { min: 260, max: 280 },
      scale: { start: 0.5, end: 0 },
      lifespan: 500,
      frequency: 200,
      tint: 0x00ff00,
    });
    emitter.setDepth(50);
    this.time.delayedCall(1000, () => emitter.destroy());
  }

  createConfetti(x, y) {
    const emitter = this.add.particles(x, y, 'particle_pixel', {
      speed: { min: 60, max: 160 },
      angle: { min: 200, max: 340 },
      scale: { start: 0.8, end: 0 },
      gravityY: 200,
      lifespan: 1200,
      frequency: 40,
      tint: [0xffb000, 0x00e5ff, 0xff4d5e, 0x6abe30],
    });
    emitter.setDepth(96);
    this.time.delayedCall(4000, () => emitter.destroy());
  }

  // --- TOOLTIP ---
  setupTooltip() {
    this.tooltip = this.add
      .text(0, 0, '', {
        font: '12px monospace',
        fill: '#ffffff',
        backgroundColor: '#000000dd',
        padding: { x: 8, y: 8 },
      })
      .setDepth(1100)
      .setVisible(false)
      .setScrollFactor(0);
  }

  showTooltip(x, y, text) {
    this.tooltip.setScrollFactor(1);
    this.tooltip.setPosition(x, y);
    this.tooltip.setText(text);
    this.tooltip.setVisible(true);
  }

  hideTooltip() {
    this.tooltip.setVisible(false);
  }

  // --- DAY/NIGHT ---
  setupDayNightCycle() {
    this.dayNightOverlay = this.add
      .rectangle(400, 300, 8000, 6000, 0x000033)
      .setDepth(90)
      .setAlpha(0);
  }

  updateDayNight(tick) {
    if (tick > 40) {
      const darkness = (tick - 40) / 20;
      this.dayNightOverlay.setAlpha(darkness * 0.6);
    } else {
      this.dayNightOverlay.setAlpha(0);
    }
  }

  // --- GRID / PATHFINDING ---
  setupGrid() {
    this.pathfinder = new Pathfinder();
    this.cols = 25;
    this.rows = 20;
    this.tileSize = 32;
    this._grid = Array.from({ length: this.rows }, () => Array(this.cols).fill(0));
    this.pathfinder.setGrid(this._grid);
  }

  /** Grid derived from real objects: perimeter walls + every registered blocker. */
  applyObstaclesToGrid() {
    if (!this._grid) return;
    for (let y = 0; y < this.rows; y++) {
      for (let x = 0; x < this.cols; x++) this._grid[y][x] = 0;
    }
    for (let x = 0; x < this.cols; x++) {
      this._grid[0][x] = 1;
      this._grid[this.rows - 1][x] = 1;
    }
    for (let y = 1; y < this.rows - 1; y++) {
      this._grid[y][0] = 1;
      this._grid[y][this.cols - 1] = 1;
    }
    for (const b of this.blockers) {
      if (b.x >= 0 && b.x < this.cols && b.y >= 0 && b.y < this.rows) {
        this._grid[b.y][b.x] = 1;
      }
    }
    this.pathfinder.setGrid(this._grid);
  }

  createWalls() {
    for (let x = 0; x < this.cols; x++) {
      this.spawnWall(x, 0);
      this.spawnWall(x, this.rows - 1);
    }
    for (let y = 1; y < this.rows - 1; y++) {
      this.spawnWall(0, y);
      this.spawnWall(this.cols - 1, y);
    }
  }

  spawnWall(x, y) {
    const wall = this.add.image(
      x * this.tileSize + this.tileSize / 2,
      y * this.tileSize + this.tileSize / 2,
      'wall'
    );
    wall.setDepth(wall.y);
    this.objectGroup.add(wall);
  }

  requestMove(worker, x, y) {
    const startX = Math.floor(worker.x / this.tileSize);
    const startY = Math.floor(worker.y / this.tileSize);
    const endX = Phaser.Math.Clamp(x, 0, this.cols - 1);
    const endY = Phaser.Math.Clamp(y, 0, this.rows - 1);
    this.pathfinder.findPath(startX, startY, endX, endY, (path) => {
      if (worker.active) worker.startPath(path);
    });
  }

  // --- FLOOR ---
  createFloor(level) {
    if (this.floorTexture) this.floorTexture.destroy();
    this.floorTexture = this.add
      .renderTexture(0, 0, this.cols * this.tileSize, this.rows * this.tileSize)
      .setOrigin(0, 0)
      .setDepth(0);
    const textureKey = `floor_${Phaser.Math.Clamp(level, 1, 3)}`;
    this.floorTexture.beginDraw();
    for (let x = 0; x < this.cols; x++) {
      for (let y = 0; y < this.rows; y++) {
        this.floorTexture.batchDrawFrame(textureKey, 0, x * this.tileSize, y * this.tileSize);
      }
    }
    this.floorTexture.endDraw();
  }

  addFootprint(x, y) {
    if (this.floorTexture) {
      if (!this._footprintGraphics) {
        this._footprintGraphics = this.make.graphics({ add: false });
        this._footprintGraphics.fillStyle(0x000000, 0.1);
        this._footprintGraphics.fillCircle(0, 0, 2);
      }
      this.floorTexture.draw(this._footprintGraphics, x, y);
    }
  }

  // --- OBJECTS (layout kept from repo; blockers + desk registry added) ---
  spawnObjects() {
    this.objectGroup?.clear(true, true);

    // SERVER ROOM (top left)
    this.spawnObject(2, 2, 'obj_server');
    this.spawnObject(3, 2, 'obj_server');
    this.spawnObject(4, 2, 'obj_server');
    this.spawnObject(2, 3, 'obj_server');

    // DEV AREA — desks registered for work behavior
    for (let row = 6; row <= 12; row += 3) {
      for (let col = 3; col <= 8; col += 2) {
        this.spawnObject(col, row, 'obj_desk');
        this.spawnObject(col, row - 1, 'obj_chair', { walkable: true });
        this.desks.push({ gx: col, gy: row, chairGx: col, chairGy: row - 1, zone: 'dev', claimedBy: null });
      }
    }
    this.spawnObject(3, 14, 'obj_whiteboard');
    this.spawnObject(8, 14, 'obj_printer');

    // MEETING ROOM (top right)
    this.spawnObject(18, 4, 'obj_table_meeting', { tiles: [[18, 4], [19, 4]] });
    this.spawnObject(18, 3, 'obj_chair', { walkable: true });
    this.spawnObject(19, 3, 'obj_chair', { walkable: true });
    this.spawnObject(18, 5, 'obj_chair', { walkable: true });
    this.spawnObject(19, 5, 'obj_chair', { walkable: true });

    // SALES/SUPPORT (bottom right)
    for (let row = 10; row <= 16; row += 3) {
      for (let col = 16; col <= 21; col += 3) {
        this.spawnObject(col, row, 'obj_desk');
        this.spawnObject(col, row - 1, 'obj_chair', { walkable: true });
        this.desks.push({ gx: col, gy: row, chairGx: col, chairGy: row - 1, zone: 'sales', claimedBy: null });
      }
    }
    this.spawnObject(22, 12, 'obj_cabinet');
    this.spawnObject(22, 13, 'obj_cabinet');

    // LOUNGE
    this.spawnObject(12, 16, 'obj_rug', { walkable: true });
    this.spawnObject(11, 16, 'obj_couch', { walkable: true });
    this.spawnObject(13, 16, 'obj_couch', { walkable: true });
    this.spawnObject(23, 17, 'obj_coffee_anim', { animated: true });
    this.spawnObject(21, 17, 'obj_vending');
    this.spawnObject(19, 17, 'obj_watercooler');

    // Plants
    this.spawnObject(2, 17, 'obj_plant');
    this.spawnObject(23, 1, 'obj_plant');
    this.spawnObject(10, 10, 'obj_plant');
  }

  /**
   * Spawns an object AND registers its footprint on the pathfinding grid.
   * @param {Object} [opts] - { walkable, animated, tiles: [[gx,gy],...] }
   */
  spawnObject(x, y, texture, opts = {}) {
    const isAnimated = opts === true || opts.animated;
    let obj;
    const px = x * this.tileSize + this.tileSize / 2;
    const py = y * this.tileSize + this.tileSize / 2;
    if (isAnimated) {
      obj = this.add.sprite(px, py, texture);
      if (texture === 'obj_coffee_anim') {
        obj.play('coffee_drain');
        obj.setInteractive();
        obj.on('pointerdown', () => {
          obj.play('coffee_refill');
          this.soundManager.play('kaching');
        });
      }
    } else {
      obj = this.add.image(px, py, texture);
    }

    obj.setDepth(obj.y);
    this.objectGroup.add(obj);

    // Register grid blockers (source of truth for pathfinding)
    if (!opts.walkable) {
      const tiles = opts.tiles || [[x, y]];
      for (const [gx, gy] of tiles) this.blockers.push({ x: gx, y: gy });
    }

    return obj;
  }

  // --- WORKERS ---
  syncEmployees(employees = []) {
    const sprites = this.workersGroup.getChildren();
    const wantedIds = new Set(employees.map((e) => String(e.id)));
    const existingIds = new Set();
    for (let i = sprites.length - 1; i >= 0; i--) {
      const sprite = sprites[i];
      const id = String(sprite.id);
      if (!wantedIds.has(id)) sprite.destroy();
      else existingIds.add(id);
    }
    employees.forEach((e) => {
      if (!existingIds.has(String(e.id))) this.spawnWorker(e.role, e.id, e.trait);
    });
    this.refreshWorkerTints();
  }

  spawnWorker(role, id = Date.now(), trait = 'NORMAL') {
    const x = Phaser.Math.Between(1, this.cols - 2);
    const y = Phaser.Math.Between(1, this.rows - 2);
    const worker = new WorkerSprite(
      this,
      x * this.tileSize + this.tileSize / 2,
      y * this.tileSize + this.tileSize / 2,
      role, id, trait
    );
    this.add.existing(worker);
    this.workersGroup.add(worker);
  }

  // --- VISITORS ---
  syncVisitors(activeVisitors) {
    this.manageVisitor('visitor_pizza', activeVisitors.includes('pizza_guy'), 0, 300, 400, 300);
    this.manageVisitor('visitor_investor', activeVisitors.includes('investors'), 800, 300, 600, 300, 3);
  }

  manageVisitor(key, isActive, startX, startY, endX, endY, count = 1) {
    const sprites = this.visitorGroup.getChildren().filter((v) => v.texture?.key === key);
    if (isActive && sprites.length === 0) {
      if (key === 'visitor_pizza') {
        this.spawnPizzaGuyOrbit();
      } else {
        for (let i = 0; i < count; i++) {
          const v = this.add.sprite(startX, startY + i * 40, key);
          this.physics.add.existing(v);
          this.tweens.add({ targets: v, x: endX, duration: 2000 });
          v.once(Phaser.GameObjects.Events.DESTROY, () => this.tweens.killTweensOf(v));
          this.visitorGroup.add(v);
        }
      }
    } else if (!isActive && sprites.length > 0) {
      sprites.forEach((s) => {
        this.tweens.killTweensOf(s);
        s.destroy();
      });
    }
  }

  spawnPizzaGuyOrbit() {
    const path = new Phaser.Curves.Path(400 + 250, 300);
    path.ellipseTo(250, 150, 0, 360, false, 0);
    const pizzaGuy = this.add.follower(path, 0, 0, 'visitor_pizza');
    pizzaGuy.startFollow({ duration: 10000, repeat: -1, rotateToPath: false, ease: 'Linear' });
    this.visitorGroup.add(pizzaGuy);
  }

  // --- CHAOS / MOOD VISUALS ---
  refreshWorkerTints(moodOverride) {
    const state = useGameStore.getState();
    const events = state?.activeEvents || [];
    const mood = moodOverride ?? state?.mood ?? 100;
    let tint = mood > 80 ? 0xffffff : mood > 40 ? 0xccccff : 0x8888ff;
    if (state?.isRefactoring) tint = 0x888888;
    if (events.some((e) => e.type === 'HUMAN_SICK')) tint = 0x88ff88;
    this.workersGroup.children.iterate((w) => w?.setTint?.(tint));
  }

  updateMoodVisuals(mood) {
    this.refreshWorkerTints(mood);
  }

  syncChaosVisuals(events) {
    if (this._chaosTweens?.length) this._chaosTweens.forEach((t) => t.stop());
    this._chaosTweens = [];
    this.overlayGroup?.clear(true, true);
    if (this._surgeTimer) { this._surgeTimer.remove(); this._surgeTimer = null; }

    for (const e of events) {
      if (e.type === 'TECH_OUTAGE') {
        const rect = this.add.rectangle(400, 300, 800, 600, 0x0000aa, 0.3).setDepth(91);
        this.overlayGroup.add(rect);
        this.addOverlayText('SYSTEM FAILURE', '#0000ff');
        this.createSmoke(2 * 32, 2 * 32);
        this.workersGroup.children.iterate((w) => w?.showFeedback?.('???'));
      } else if (e.type === 'RANSOMWARE') {
        const skull = this.add.text(400, 300, '💀', { fontSize: '200px' }).setOrigin(0.5).setDepth(92);
        this.overlayGroup.add(skull);
        const tween = this.tweens.add({ targets: skull, alpha: 0.5, yoyo: true, repeat: -1, duration: 500 });
        this._chaosTweens.push(tween);
        skull.once(Phaser.GameObjects.Events.DESTROY, () => this.tweens.killTweensOf(skull));
        this.addOverlayText('RANSOMWARE: PAY UP', '#ff0000');
      } else if (e.type === 'MARKET_SHITSTORM') {
        this.addOverlayText('SHITSTORM IN PROGRESS', '#aa0000');
        this.cameras.main.shake(100, 0.005);
      } else if (e.type === 'COMPETITOR_CLONE') {
        this.addOverlayText('COMPETITOR DETECTED', '#aa0000');
      } else if (e.type === 'PIZZA_PARTY') {
        this.addOverlayText('PIZZA PARTY!', '#e8890c');
        this.createConfetti(400, 200);
      } else if (e.type === 'POWER_SURGE') {
        this.addOverlayText('POWER SURGE', '#ccaa00');
        // Ambient flicker while active
        this._surgeTimer = this.time.addEvent({
          delay: 300, loop: true,
          callback: () => {
            this.dayNightOverlay.setAlpha(Math.random() > 0.4 ? 0 : 0.35);
          },
        });
      } else if (e.type === 'INVESTOR_VISIT') {
        this.addOverlayText('INVESTORS ON SITE', '#ffb000');
      }
    }
    if (!events.some((e) => e.type === 'POWER_SURGE')) {
      this.updateDayNight(useGameStore.getState().tick);
    }
    this.refreshWorkerTints();
  }

  // --- OFFICE ASSETS (upgrades & decisions leave traces) ---
  addOfficeAsset(key, asset) {
    if (!asset || this._officeAssetKeys.has(key)) return;
    const obj = this.spawnObject(asset.x, asset.y, asset.texture, { animated: asset.animated });
    obj.officeAssetKey = key;
    obj.setDepth(obj.y + 1);
    const label = this.add
      .text(obj.x, obj.y - 22, asset.label, {
        fontSize: '8px',
        color: '#10131d',
        backgroundColor: '#ffb000',
        padding: { x: 3, y: 1 },
      })
      .setOrigin(0.5)
      .setDepth(obj.y + 2);
    this.objectGroup.add(label);
    this._officeAssetKeys.add(key);
    this.applyObstaclesToGrid(); // new furniture blocks paths immediately
    this.createCodeBits(obj.x, obj.y - 12);
  }

  addOfficeAssetForInventory(item) {
    const assetMap = {
      firewall: { x: 5, y: 2, texture: 'obj_firewall', label: 'FIREWALL' },
      server_rack_v2: { x: 5, y: 3, texture: 'obj_server_v2', label: 'SERVER V2' },
      plants: { x: 14, y: 14, texture: 'obj_plant', label: 'GREENERY' },
      coffee_machine: { x: 22, y: 17, texture: 'obj_coffee_anim', label: 'COFFEE', animated: true },
      war_room: { x: 17, y: 6, texture: 'obj_war_room', label: 'WAR ROOM' },
      brand_studio: { x: 20, y: 7, texture: 'obj_brand_studio', label: 'BRAND LAB' },
      wellness_pod: { x: 9, y: 16, texture: 'obj_wellness_pod', label: 'WELLNESS' },
    };
    this.addOfficeAsset(`inventory:${item}`, assetMap[item]);
  }

  addOfficeAssetForAction(action) {
    const assetMap = {
      FUNDRAISE: { x: 15, y: 4, texture: 'obj_investor_plaque', label: 'TERM SHEET' },
      CUSTOMER_RESEARCH: { x: 4, y: 14, texture: 'obj_research_wall', label: 'RESEARCH' },
      INCIDENT_DRILL: { x: 6, y: 4, texture: 'obj_incident_kit', label: 'DRILL KIT' },
      MARKETING_PUSH: { x: 21, y: 7, texture: 'obj_brand_studio', label: 'CAMPAIGN' },
    };
    this.addOfficeAsset(`action:${action}`, assetMap[action]);
  }

  syncInventoryVisuals(inventory) {
    if (!inventory) return;
    inventory.forEach((item) => this.addOfficeAssetForInventory(item));
  }

  syncDecisionOfficeAssets(history = []) {
    history.filter((e) => !e.vetoed).forEach((e) => this.addOfficeAssetForAction(e.action));
  }

  addOverlayText(msg, color) {
    const t = this.add
      .text(400, 100, msg, {
        fontSize: '32px',
        color: '#fff',
        backgroundColor: color,
        padding: { x: 10, y: 10 },
      })
      .setOrigin(0.5)
      .setDepth(93);
    this.overlayGroup.add(t);
  }

  // --- CLEANUP ---
  onShutdown() {
    this.unsubscribers.forEach((u) => u());
    this.unsubscribers = [];
    this._timers?.forEach((t) => t.remove());
    this._surgeTimer?.remove();
    this.tweens.killAll();
    if (this.mouseLight) { this.mouseLight = null; }
    if (this._footprintGraphics) { this._footprintGraphics.destroy(); this._footprintGraphics = null; }
    if (this.floorTexture) { this.floorTexture.destroy(); this.floorTexture = null; }
    this.objectGroup?.clear(true, true);
    this.workersGroup?.clear(true, true);
    this.visitorGroup?.clear(true, true);
    this.overlayGroup?.clear(true, true);
    this.input?.off('pointermove', this._onPointerMove);
    this.input?.removeAllListeners();
    window.removeEventListener('ZOOM_IN', this._onZoomIn);
    window.removeEventListener('ZOOM_OUT', this._onZoomOut);
    this.pathfinder = null;
    this._grid = null;
    this._chaosTweens = [];
  }
}
