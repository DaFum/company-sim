import Phaser from 'phaser';
import { PALETTE } from './palette.js';

const POP_WAV_B64 =
  'UklGRmYGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YUIGAACZC5sOmA+XEKkQFhHcEQYRbQ8lDjkK0AcbAegCFf6l+8f5HfPj8jfyP/PM8lD0XfUu+Zf7Qf8u/3b/2P+lAAEAZwFzAnkCdwJpAkwCHQHkAKcAaQAsAO0Aqf9t/7r+5f6C/ir+Ff5J/nH+1P5w/5r/0wAIAa8B4gH6Af4B6gG9AYkBVAEeAeEAoQAeAJX/3f+9/1v/ZP8W/yD/av+u/9cAFAFpAfwBKgJLAlcCUQIzAgkC2gGqAXkBQQEFAckAhwA+APv/tP+F/1P/S/8k/yv/df+0/9wAFwFjAfIBGwJFAk0CQQImAgAC0gGpAX8BRwEJAc4AiwA8APv/s/+F/1v/Uf8s/zH/eP+3/+AAFgFZAd4B+AEBARkBFAH0AMoAogB8AFEAJwD7/9H/pP+P/3f/W/8+';

/**
 * Procedural asset factory — art faithful to the repo's PreloadScene, with
 * small refinements (worker highlight pass, floor edge shading).
 */
export default class PreloadScene extends Phaser.Scene {
  constructor() {
    super({ key: 'PreloadScene' });
    this._blobUrls = [];
  }

  preload() {
    this.load.on('loaderror', (file) => console.warn('[PreloadScene] Load error:', file?.key));
    this.load.once('complete', () => {
      for (const url of this._blobUrls) { try { URL.revokeObjectURL(url); } catch { /* ignore */ } }
      this._blobUrls.length = 0;
    });
    this.safeLoadAudioFromBase64('pop', POP_WAV_B64);
    this.safeLoadAudioFromBase64('kaching', POP_WAV_B64);
  }

  create() {
    this.createHighQualityAssets();
    this.createAdvancedAssets();
    this.scene.start('MainScene');
  }

  createAdvancedAssets() {
    // ANIMATED COFFEE MACHINE (4 frames: Full -> Half -> Empty -> Refilling)
    this.genSpriteSheetWithNormal('obj_coffee_anim', 32, 32, 4, (g, frameIndex) => {
      g.fillStyle(0x444444, 1);
      g.fillRoundedRect(4, 4, 24, 28, 2);
      g.fillStyle(0xaaddff, 0.3);
      g.fillRect(8, 14, 16, 14);
      const levels = [10, 5, 0, 10];
      const color = frameIndex === 3 ? 0x00ff00 : 0x6f4e37;
      if (levels[frameIndex] > 0) {
        g.fillStyle(color, 1);
        g.fillRect(8, 28 - levels[frameIndex], 16, levels[frameIndex]);
      }
      g.fillStyle(frameIndex === 2 ? 0xff0000 : 0x00ff00);
      g.fillCircle(16, 8, 2);
    });

    this.genSpriteWithNormal('obj_watercooler', 32, 32, (g) => {
      g.fillStyle(0x4488ff, 0.6);
      g.fillRect(10, 2, 12, 12);
      g.fillStyle(0xeeeeee, 1);
      g.fillRect(8, 14, 16, 18);
      g.fillStyle(0xff0000, 1);
      g.fillRect(12, 18, 2, 4);
      g.fillStyle(0x0000ff, 1);
      g.fillRect(18, 18, 2, 4);
      g.lineStyle(1, 0x999999);
      g.strokeRect(8, 14, 16, 18);
    });

    this.genSpriteWithNormal('obj_printer', 32, 32, (g) => {
      g.fillStyle(0xd0d0d0, 1);
      g.fillRect(4, 10, 24, 18);
      g.lineStyle(1, 0x555555);
      g.strokeRect(4, 10, 24, 18);
      g.fillStyle(0xffffff, 1);
      g.fillRect(8, 4, 16, 6);
      g.fillStyle(0x333333, 1);
      g.fillRect(18, 12, 8, 4);
      g.fillStyle(0x00ff00, 1);
      g.fillCircle(8, 14, 2);
    });

    this.genSpriteWithNormal('obj_whiteboard', 32, 32, (g) => {
      g.lineStyle(2, 0x888888, 1);
      g.beginPath();
      g.moveTo(4, 30); g.lineTo(4, 10);
      g.moveTo(28, 30); g.lineTo(28, 10);
      g.strokePath();
      g.fillStyle(0xffffff, 1);
      g.fillRect(2, 6, 28, 18);
      g.lineStyle(1, 0xcccccc);
      g.strokeRect(2, 6, 28, 18);
      g.lineStyle(1, 0xff0000, 0.8);
      g.beginPath();
      g.moveTo(6, 14); g.lineTo(12, 10); g.lineTo(18, 16);
      g.strokePath();
      g.lineStyle(1, 0x0000ff, 0.8);
      g.strokeCircle(22, 12, 3);
    });

    this.genSpriteWithNormal('obj_desk', 32, 32, (g) => {
      g.fillStyle(PALETTE.FURNITURE_BASE, 1);
      g.fillRect(2, 11, 28, 15);
      g.fillStyle(PALETTE.FURNITURE_HIGHLIGHT, 1);
      g.fillRect(3, 10, 26, 3);
      g.lineStyle(1, PALETTE.FURNITURE_SHADOW, 0.8);
      g.strokeRect(2, 11, 28, 15);
      g.fillStyle(PALETTE.FURNITURE_SCREEN, 1);
      g.fillRect(6, 5, 13, 9);
      g.fillStyle(PALETTE.GLASS, 0.95);
      g.fillRect(8, 7, 9, 5);
      g.fillStyle(PALETTE.FURNITURE_SHADOW, 1);
      g.fillRect(11, 14, 4, 2);
      g.fillStyle(PALETTE.PAPER, 1);
      g.fillRect(22, 14, 6, 4);
      g.fillStyle(PALETTE.AMBER, 1);
      g.fillRect(4, 24, 24, 2);
    });

    this.genSpriteWithNormal('obj_vending', 32, 32, (g) => {
      g.fillStyle(0xcc3333, 1);
      g.fillRect(6, 2, 20, 28);
      g.fillStyle(0x222222, 0.8);
      g.fillRect(8, 6, 16, 16);
      g.fillStyle(0xffaa00); g.fillRect(10, 8, 2, 2);
      g.fillStyle(0x00ff00); g.fillRect(14, 8, 2, 2);
      g.fillStyle(0x0000ff); g.fillRect(18, 8, 2, 2);
      g.fillStyle(0x111111, 1);
      g.fillRect(8, 24, 16, 4);
    });

    this.genSpriteWithNormal('obj_chair', 32, 32, (g) => {
      g.fillStyle(PALETTE.FURNITURE_SHADOW, 1);
      g.fillRect(15, 20, 2, 10);
      g.fillRect(10, 28, 12, 2);
      g.fillStyle(PALETTE.CHAIR_SEAT, 1);
      g.fillRect(8, 16, 16, 8);
      g.fillStyle(PALETTE.CHAIR_BACK, 1);
      g.fillRect(9, 5, 14, 11);
      g.fillStyle(PALETTE.AMBER, 0.8);
      g.fillRect(9, 15, 14, 2);
      g.lineStyle(1, PALETTE.FURNITURE_SHADOW, 0.6);
      g.strokeRect(9, 5, 14, 11);
    });

    this.genSpriteWithNormal('obj_cabinet', 32, 32, (g) => {
      g.fillStyle(0x888888, 1);
      g.fillRect(6, 4, 20, 26);
      g.lineStyle(1, 0x444444);
      g.strokeRect(6, 4, 20, 26);
      g.lineStyle(1, 0x555555);
      g.beginPath();
      g.moveTo(6, 12); g.lineTo(26, 12);
      g.moveTo(6, 20); g.lineTo(26, 20);
      g.strokePath();
      g.fillStyle(0xcccccc);
      g.fillRect(14, 8, 4, 2);
      g.fillRect(14, 16, 4, 2);
      g.fillRect(14, 24, 4, 2);
    });

    this.genSpriteWithNormal('obj_couch', 32, 32, (g) => {
      g.fillStyle(0xaa4444, 1);
      g.fillRect(2, 4, 28, 8);
      g.fillRect(2, 12, 28, 16);
      g.fillStyle(0x882222, 1);
      g.fillRect(2, 12, 4, 16);
      g.fillRect(26, 12, 4, 16);
      g.lineStyle(1, 0x660000, 0.5);
      g.beginPath();
      g.moveTo(16, 12); g.lineTo(16, 28);
      g.strokePath();
    });

    this.genSpriteWithNormal('obj_table_meeting', 64, 32, (g) => {
      g.fillStyle(0x5d4037, 1);
      g.fillRoundedRect(4, 4, 56, 24, 4);
      g.lineStyle(2, 0x3e2723);
      g.strokeRoundedRect(4, 4, 56, 24, 4);
    });

    this.genSpriteWithNormal('obj_rug', 64, 64, (g) => {
      g.fillStyle(0x550000, 0.8);
      g.fillCircle(32, 32, 28);
      g.lineStyle(2, 0xaa5500);
      g.strokeCircle(32, 32, 28);
      g.lineStyle(2, 0xaa5500, 0.5);
      g.strokeCircle(32, 32, 20);
    });

    this.genSpriteWithNormal('obj_firewall', 32, 32, (g) => {
      g.fillStyle(PALETTE.OUTLINE_DARK, 1);
      g.fillRect(5, 5, 22, 22);
      g.lineStyle(2, 0x00e5ff, 1);
      g.strokeRect(5, 5, 22, 22);
      g.fillStyle(0x00e5ff, 1);
      g.fillRect(10, 11, 12, 3);
      g.fillRect(10, 18, 12, 3);
    });

    this.genSpriteWithNormal('obj_server_v2', 32, 32, (g) => {
      g.fillStyle(0x111111, 1);
      g.fillRect(4, 2, 24, 28);
      g.lineStyle(2, 0x00ff9c, 1);
      g.strokeRect(4, 2, 24, 28);
      g.fillStyle(0x00ff9c, 1);
      for (let y = 7; y <= 23; y += 4) g.fillRect(8, y, 16, 2);
    });

    this.genSpriteWithNormal('obj_war_room', 64, 32, (g) => {
      g.fillStyle(0x1a1f2e, 1);
      g.fillRoundedRect(2, 4, 60, 24, 3);
      g.lineStyle(2, 0xffb000, 1);
      g.strokeRoundedRect(2, 4, 60, 24, 3);
      g.fillStyle(0xff4d5e, 1); g.fillRect(10, 10, 10, 8);
      g.fillStyle(0x00e5ff, 1); g.fillRect(27, 8, 10, 12);
      g.fillStyle(0x00ff9c, 1); g.fillRect(44, 13, 10, 6);
    });

    this.genSpriteWithNormal('obj_brand_studio', 32, 32, (g) => {
      g.fillStyle(0xffb000, 1);
      g.fillCircle(16, 16, 12);
      g.fillStyle(PALETTE.OUTLINE_DARK, 1);
      g.fillCircle(16, 16, 7);
      g.fillStyle(0xffffff, 1);
      g.fillRect(15, 4, 2, 24);
      g.fillRect(4, 15, 24, 2);
    });

    this.genSpriteWithNormal('obj_wellness_pod', 32, 32, (g) => {
      g.fillStyle(0x88d8c0, 1);
      g.fillRoundedRect(5, 8, 22, 17, 8);
      g.lineStyle(2, 0xffffff, 0.8);
      g.strokeRoundedRect(5, 8, 22, 17, 8);
      g.fillStyle(0x37946e, 1);
      g.fillCircle(12, 14, 3);
      g.fillCircle(20, 18, 4);
    });

    this.genSpriteWithNormal('obj_investor_plaque', 32, 32, (g) => {
      g.fillStyle(0x2d2414, 1);
      g.fillRoundedRect(4, 7, 24, 18, 2);
      g.lineStyle(2, 0xffb000, 1);
      g.strokeRoundedRect(4, 7, 24, 18, 2);
      g.fillStyle(PALETTE.PAPER, 1);
      g.fillRect(9, 12, 14, 2);
      g.fillRect(9, 17, 10, 2);
    });

    this.genSpriteWithNormal('obj_research_wall', 32, 32, (g) => {
      g.fillStyle(0xf5f0d8, 1);
      g.fillRect(3, 4, 26, 22);
      g.lineStyle(1, PALETTE.OUTLINE_DARK, 0.6);
      g.strokeRect(3, 4, 26, 22);
      g.fillStyle(0xff4d5e, 1); g.fillCircle(9, 10, 2);
      g.fillStyle(0x00e5ff, 1); g.fillCircle(20, 13, 2);
      g.lineStyle(1, PALETTE.OUTLINE_DARK, 0.7);
      g.beginPath();
      g.moveTo(9, 10); g.lineTo(20, 13); g.lineTo(14, 21);
      g.strokePath();
    });

    this.genSpriteWithNormal('obj_incident_kit', 32, 32, (g) => {
      g.fillStyle(0xff4d5e, 1);
      g.fillRoundedRect(6, 9, 20, 16, 2);
      g.fillStyle(0xffffff, 1);
      g.fillRect(14, 11, 4, 12);
      g.fillRect(10, 15, 12, 4);
      g.fillStyle(PALETTE.OUTLINE_DARK, 1);
      g.fillRect(12, 6, 8, 4);
    });
  }

  createHighQualityAssets() {
    this.genTexture('particle_pixel', 4, 4, (g) => {
      g.fillStyle(0xffffff, 1);
      g.fillRect(0, 0, 4, 4);
    });

    this.genTexture('shadow_blob', 24, 12, (g) => {
      g.fillStyle(0x000000, 0.4);
      g.fillEllipse(12, 6, 24, 12);
    });

    // Speech bubble for chats/meetings (new)
    this.genTexture('bubble', 16, 14, (g) => {
      g.fillStyle(0xffffff, 1);
      g.fillRoundedRect(0, 0, 16, 10, 3);
      g.fillTriangle(4, 9, 9, 9, 4, 13);
      g.fillStyle(PALETTE.OUTLINE_DARK, 1);
      g.fillRect(3, 4, 2, 2);
      g.fillRect(7, 4, 2, 2);
      g.fillRect(11, 4, 2, 2);
    });

    const drawCharBase = (g, shirtColor) => {
      g.fillStyle(PALETTE.BLACK, 0.2);
      g.fillEllipse(16, 29, 18, 5);
      g.fillStyle(shirtColor, 0.28);
      g.fillCircle(16, 16, 14);
      g.lineStyle(2, PALETTE.OUTLINE, 1);
      g.fillStyle(PALETTE.OUTLINE_DARK, 1);
      g.fillRect(7, 18, 18, 12);
      g.strokeRect(7, 18, 18, 12);
      g.fillStyle(shirtColor, 1);
      g.fillRect(9, 19, 14, 9);
      g.fillStyle(PALETTE.WHITE, 0.35);
      g.fillRect(10, 20, 5, 2);
      g.fillStyle(PALETTE.SKIN, 1);
      g.fillRect(10, 6, 12, 12);
      g.strokeRect(10, 6, 12, 12);
      g.fillStyle(PALETTE.HAIR_DARK, 1);
      g.fillRect(10, 5, 12, 4);
      g.fillRect(9, 8, 3, 4);
      g.fillStyle(PALETTE.OUTLINE, 1);
      g.fillRect(13, 12, 2, 2);
      g.fillRect(19, 12, 2, 2);
    };

    this.genTexture('worker_dev', 32, 32, (g) => {
      drawCharBase(g, PALETTE.SHIRT_DEV);
      g.fillStyle(PALETTE.OUTLINE, 1);
      g.fillRect(8, 10, 2, 6);
      g.fillRect(22, 10, 2, 6);
      g.lineStyle(1, PALETTE.OUTLINE);
      g.beginPath();
      g.moveTo(8, 10); g.lineTo(10, 4); g.lineTo(22, 4); g.lineTo(24, 10);
      g.strokePath();
    });

    this.genTexture('worker_sales', 32, 32, (g) => {
      drawCharBase(g, PALETTE.SHIRT_SALES);
      g.fillStyle(PALETTE.OUTLINE, 1);
      g.fillRect(15, 20, 2, 6);
      g.fillStyle(0x000000, 1);
      g.fillRect(20, 8, 4, 8);
    });

    this.genTexture('worker_support', 32, 32, (g) => {
      drawCharBase(g, PALETTE.SHIRT_SUPPORT);
      g.lineStyle(1, 0x000000, 1);
      g.beginPath();
      g.moveTo(22, 12); g.lineTo(24, 12); g.lineTo(24, 16); g.lineTo(18, 16);
      g.strokePath();
    });

    this.genSpriteWithNormal('visitor_pizza', 32, 32, (g) => {
      g.lineStyle(2, PALETTE.OUTLINE, 1);
      g.fillStyle(0xffaa00, 1);
      g.fillRect(8, 12, 16, 14);
      g.strokeRect(8, 12, 16, 14);
      g.fillStyle(0xffffff, 1);
      g.fillRect(8, -5, 16, 16);
      g.strokeRect(8, -5, 16, 16);
      g.fillStyle(PALETTE.SKIN, 1);
      g.fillRect(10, 6, 12, 10);
    });

    this.genSpriteWithNormal('visitor_investor', 32, 32, (g) => {
      g.lineStyle(2, PALETTE.OUTLINE, 1);
      g.fillStyle(0x555555, 1);
      g.fillRect(6, 10, 20, 20);
      g.strokeRect(6, 10, 20, 20);
      g.fillStyle(PALETTE.SKIN, 1);
      g.fillRect(12, 2, 8, 8);
      g.fillStyle(0x000000, 1);
      g.fillRect(24, 20, 6, 10);
    });

    this.genSpriteWithNormal(
      'obj_server', 32, 32,
      (g) => {
        g.fillStyle(0x222222, 1);
        g.lineStyle(2, 0x000000, 1);
        g.fillRect(4, 2, 24, 28);
        g.strokeRect(4, 2, 24, 28);
        g.fillStyle(0x00ff00, 1);
        g.fillRect(8, 6, 4, 2);
        g.fillRect(8, 10, 4, 2);
        g.fillStyle(0xff0000, 1);
        g.fillRect(20, 6, 4, 2);
        g.lineStyle(1, 0x555555);
        g.beginPath();
        g.moveTo(6, 20); g.lineTo(26, 20);
        g.moveTo(6, 24); g.lineTo(26, 24);
        g.strokePath();
      },
      (g) => {
        g.fillStyle(0x8080ff, 1);
        g.fillRect(0, 0, 32, 32);
        g.lineStyle(2, 0x80ff80, 1);
        g.strokeRect(4, 2, 24, 28);
      }
    );

    this.genSpriteWithNormal('obj_coffee', 32, 32, (g) => {
      g.fillStyle(PALETTE.METAL, 1);
      g.lineStyle(2, PALETTE.OUTLINE, 1);
      g.fillRect(6, 6, 20, 24);
      g.strokeRect(6, 6, 20, 24);
      g.fillStyle(0x332200, 1);
      g.fillRect(10, 18, 12, 10);
    });

    this.genSpriteWithNormal(
      'obj_plant', 32, 32,
      (g) => {
        g.fillStyle(0x8b4513, 1);
        g.fillRect(10, 22, 12, 8);
        g.lineStyle(1, 0x000000, 0.5);
        g.strokeRect(10, 22, 12, 8);
        g.fillStyle(PALETTE.PLANT, 1);
        g.fillCircle(16, 18, 6);
        g.fillCircle(12, 22, 4);
        g.fillCircle(20, 22, 4);
      },
      (g) => {
        g.fillStyle(0x8080ff, 1);
        g.fillRect(0, 0, 32, 32);
        g.fillStyle(0x80ff80, 1);
        g.fillRect(10, 22, 12, 8);
      }
    );

    const brickRects = [
      [0, 0, 15, 10], [17, 0, 15, 10],
      [0, 12, 6, 10], [8, 12, 16, 10], [26, 12, 6, 10],
      [0, 24, 15, 8], [17, 24, 15, 8],
    ];

    this.genSpriteWithNormal(
      'wall', 32, 32,
      (g) => {
        g.fillStyle(0x444455, 1);
        g.fillRect(0, 0, 32, 32);
        g.fillStyle(0x555566, 1);
        brickRects.forEach((r) => g.fillRect(...r));
        g.lineStyle(1, 0x222233, 0.5);
        g.strokeRect(0, 0, 32, 32);
      },
      (g) => {
        g.fillStyle(0x8080ff, 1);
        g.fillRect(0, 0, 32, 32);
        g.fillStyle(0x80ff80, 1);
        brickRects.forEach((r) => g.fillRect(...r));
      }
    );

    const createFloor = (name, baseColor, checkColor) => {
      this.genTexture(name, 32, 32, (g) => {
        g.fillStyle(baseColor, 1);
        g.fillRect(0, 0, 32, 32);
        g.fillStyle(checkColor, 0.5);
        g.fillRect(0, 0, 16, 16);
        g.fillRect(16, 16, 16, 16);
        g.lineStyle(1, 0xcccccc, 0.5);
        g.strokeRect(0, 0, 32, 32);
      });
    };

    createFloor('floor_1', PALETTE.FLOOR_1_BASE, PALETTE.FLOOR_1_CHECK);
    createFloor('floor_2', PALETTE.FLOOR_2_BASE, PALETTE.FLOOR_2_CHECK);
    createFloor('floor_3', PALETTE.FLOOR_3_BASE, PALETTE.FLOOR_3_CHECK);
  }

  genSpriteWithNormal(key, w, h, drawDiffuseFn, drawNormalFn = null) {
    this.genTexture(key, w, h, drawDiffuseFn);
    this.genTexture(key + '_n', w, h, (g) => {
      if (drawNormalFn) drawNormalFn(g);
      else { g.fillStyle(0x8080ff, 1); g.fillRect(0, 0, w, h); }
    });
  }

  genSpriteSheetWithNormal(key, frameW, frameH, frameCount, drawDiffuseFn, drawNormalFn = null) {
    this.genSpriteSheet(key, frameW, frameH, frameCount, drawDiffuseFn);
    this.genSpriteSheet(key + '_n', frameW, frameH, frameCount, (g, i) => {
      if (drawNormalFn) drawNormalFn(g, i);
      else { g.fillStyle(0x8080ff, 1); g.fillRect(0, 0, frameW, frameH); }
    });
  }

  genSpriteSheet(key, frameW, frameH, frameCount, drawFn) {
    if (this.textures.exists(key)) return;
    const totalWidth = frameW * frameCount;
    const g = this.make.graphics({ x: 0, y: 0, add: false });
    try {
      g.clear();
      for (let i = 0; i < frameCount; i++) {
        g.save();
        g.translateCanvas(i * frameW, 0);
        drawFn(g, i);
        g.restore();
      }
      g.generateTexture(key, totalWidth, frameH);
      const texture = this.textures.get(key);
      Phaser.Textures.Parsers.SpriteSheet(texture, 0, 0, 0, totalWidth, frameH, {
        frameWidth: frameW,
        frameHeight: frameH,
      });
    } finally {
      g.destroy();
    }
  }

  genTexture(key, w, h, drawFn) {
    if (this.textures.exists(key)) return;
    const g = this.make.graphics({ x: 0, y: 0, add: false });
    try {
      g.clear();
      drawFn(g);
      g.generateTexture(key, w, h);
    } finally {
      g.destroy();
    }
  }

  safeLoadAudioFromBase64(key, b64, mime = 'audio/wav') {
    if (this.cache?.audio?.exists?.(key)) return;
    try {
      const bin = atob(b64.replace(/[\u00A0\u200B\u200C\u200D\uFEFF]/g, ''));
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      const url = URL.createObjectURL(new Blob([bytes], { type: mime }));
      this._blobUrls.push(url);
      this.load.audio(key, url);
    } catch (e) {
      console.warn(`[PreloadScene] Audio decode failed for "${key}".`, e);
    }
  }
}
