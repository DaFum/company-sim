/**
 * Lightweight A* pathfinder replacing easystarjs.
 * - Zero dependency, ~1KB, synchronous A* on a small grid is microseconds-fast.
 * - Keeps the async request/callback API MainScene used with EasyStar, with a
 *   per-frame request budget so a burst of 100 workers repathing never spikes a frame.
 * - Blocked targets are auto-remapped to the nearest walkable tile (fixes workers
 *   getting stuck when sent to furniture tiles).
 */
export default class Pathfinder {
  constructor() {
    this.grid = null;
    this.cols = 0;
    this.rows = 0;
    this.queue = [];
    this.maxRequestsPerFrame = 8;
  }

  setGrid(grid) {
    this.grid = grid;
    this.rows = grid.length;
    this.cols = grid[0]?.length || 0;
  }

  /** Queue a path request. cb(pathArray|null). */
  findPath(sx, sy, ex, ey, cb) {
    this.queue.push({ sx, sy, ex, ey, cb });
  }

  get pending() {
    return this.queue.length;
  }

  /** Call once per scene update. Processes up to maxRequestsPerFrame requests. */
  update() {
    let n = this.maxRequestsPerFrame;
    while (n-- > 0 && this.queue.length > 0) {
      const r = this.queue.shift();
      r.cb(this.solve(r.sx, r.sy, r.ex, r.ey));
    }
  }

  inBounds(x, y) {
    return x >= 0 && x < this.cols && y >= 0 && y < this.rows;
  }

  nearestOpen(x, y) {
    if (this.inBounds(x, y) && this.grid[y][x] === 0) return { x, y };
    for (let r = 1; r < 8; r++) {
      for (let dy = -r; dy <= r; dy++) {
        for (let dx = -r; dx <= r; dx++) {
          const nx = x + dx, ny = y + dy;
          if (this.inBounds(nx, ny) && this.grid[ny][nx] === 0) return { x: nx, y: ny };
        }
      }
    }
    return null;
  }

  solve(sx, sy, ex, ey) {
    const g = this.grid;
    if (!g) return null;
    const start = this.nearestOpen(sx, sy);
    const end = this.nearestOpen(ex, ey);
    if (!start || !end) return null;
    sx = start.x; sy = start.y; ex = end.x; ey = end.y;

    const C = this.cols;
    const key = (x, y) => y * C + x;
    const open = [{ x: sx, y: sy, gc: 0, f: 0, parent: null }];
    const closed = new Set();
    const best = new Map([[key(sx, sy), 0]]);
    const DIRS = [[1, 0], [-1, 0], [0, 1], [0, -1]];

    while (open.length > 0) {
      let mi = 0;
      for (let i = 1; i < open.length; i++) if (open[i].f < open[mi].f) mi = i;
      const node = open.splice(mi, 1)[0];
      if (node.x === ex && node.y === ey) {
        const path = [];
        let c = node;
        while (c) { path.unshift({ x: c.x, y: c.y }); c = c.parent; }
        return path;
      }
      closed.add(key(node.x, node.y));
      for (const [dx, dy] of DIRS) {
        const nx = node.x + dx, ny = node.y + dy;
        if (!this.inBounds(nx, ny) || g[ny][nx] === 1) continue;
        const k = key(nx, ny);
        if (closed.has(k)) continue;
        const gc = node.gc + 1;
        if (best.has(k) && best.get(k) <= gc) continue;
        best.set(k, gc);
        open.push({ x: nx, y: ny, gc, f: gc + Math.abs(ex - nx) + Math.abs(ey - ny), parent: node });
      }
    }
    return null;
  }
}
