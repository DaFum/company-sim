import Phaser from 'phaser';
import { CSS_PALETTE, ROLE_LIGHTS } from './palette.js';

const STATE = {
  IDLE: 'IDLE',
  MOVING: 'MOVING',
  WORKING: 'WORKING',
  COFFEE: 'COFFEE',
  MEETING: 'MEETING',
  BREAK: 'BREAK',
  CHAT: 'CHAT',
};

/**
 * Worker sprite — optimized & extended vs. repo version:
 * - Shared per-role particle emitters (scene.roleEmitters) instead of one emitter
 *   per worker (was: N emitters alive at all times).
 * - PointLight budget: only the first `scene.lightBudget` workers get a light.
 * - Depth set only when y actually changes (no per-frame group iterate in scene).
 * - New behaviors: desk-seeking work, meetings, couch breaks, watercooler chats.
 * - Coffee run targets the actual coffee machine (repo bug: sent workers to 23,2
 *   while the machine sits at 23,17).
 */
export default class WorkerSprite extends Phaser.Physics.Arcade.Sprite {
  constructor(scene, x, y, role, id, trait = 'NORMAL') {
    super(scene, x, y, `worker_${role}`);

    this.role = role;
    this.id = id;
    this.trait = trait;

    scene.physics.add.existing(this);
    this.setCollideWorldBounds(true);
    this.body.setSize(24, 24);
    this.body.setOffset(4, 8);

    this.shadow = scene.add.image(x, y + 13, 'shadow_blob').setAlpha(0.45);

    // Light budget: fast fake PointLights, capped globally.
    this.baseLightRadius = 72;
    this.lightJitterAmplitude = 6;
    this._hasLight = false;
    if (scene.game.renderer.type === Phaser.WEBGL && scene.requestLight()) {
      this._hasLight = true;
      this.light = scene.add
        .pointlight(x, y, ROLE_LIGHTS[role] || ROLE_LIGHTS.support, this.baseLightRadius, 0.35)
        .setDepth(this.depth - 1);
    }

    this.currentState = STATE.IDLE;
    this.stateTimer = Phaser.Math.Between(200, 1500);
    this.energy = Phaser.Math.Between(60, 100);
    this.movementIntent = null;
    this.desk = null;
    this._footprintTimer = 0;

    this.path = [];
    this.movementTarget = new Phaser.Math.Vector2();
    this._tempVec = new Phaser.Math.Vector2();
    this._lastDepthY = -1;

    this.statusIcon = scene.add
      .text(0, 0, '', {
        fontSize: '14px',
        fontFamily: 'Courier New',
        stroke: CSS_PALETTE.OUTLINE_DARK,
        strokeThickness: 2,
      })
      .setOrigin(0.5)
      .setVisible(false)
      .setDepth(900);

    this.setInteractive();
    this.on('pointerover', () => {
      scene.showTooltip(
        this.x,
        this.y - 40,
        `${this.role.toUpperCase()}\nEnergy: ${Math.max(0, this.energy).toFixed(0)}%\nTrait: ${this.trait}\nState: ${this.currentState}`
      );
      if (this.preFX && !this._glowFX) {
        this._glowFX = this.preFX.addGlow(0xffffff, 2, 0, false, 0.1, 10);
      }
    });
    this.on('pointerout', () => {
      scene.hideTooltip();
      if (this._glowFX) {
        this.preFX.remove(this._glowFX);
        this._glowFX = null;
      }
    });

    this.traitIcon = null;
    if (this.trait === '10x_ENGINEER') this.showTraitIcon('🔥', '#ff9900');
    if (this.trait === 'TOXIC') this.showTraitIcon('🤢', '#00ff00');
    if (this.trait === 'JUNIOR') this.showTraitIcon('👶', '#ffffff');
  }

  destroy(fromScene) {
    if (this._hasLight) {
      this.scene?.releaseLight?.();
      this._hasLight = false;
    }
    if (this.light) { this.light.destroy(); this.light = null; }
    if (this.shadow) { this.shadow.destroy(); this.shadow = null; }
    if (this.statusIcon) { this.statusIcon.destroy(); this.statusIcon = null; }
    if (this.traitIcon) { this.traitIcon.destroy(); this.traitIcon = null; }
    if (this.workTween) this.workTween.stop();
    if (this.feedbackTween) this.feedbackTween.stop();
    this.releaseDesk();
    super.destroy(fromScene);
  }

  releaseDesk() {
    if (this.desk) {
      this.desk.claimedBy = null;
      this.desk = null;
    }
  }

  preUpdate(time, delta) {
    super.preUpdate(time, delta);

    // Depth only when y moved (perf: replaces per-frame group iterate)
    if (this.y !== this._lastDepthY) {
      this._lastDepthY = this.y;
      this.setDepth(this.y);
      if (this.shadow) this.shadow.setDepth(this.y - 1);
      if (this.light) this.light.setDepth(this.y - 1);
    }

    if (this.light) {
      this.light.setPosition(this.x, this.y);
      this.light.radius = this.baseLightRadius + Math.sin(time * 0.005) * this.lightJitterAmplitude;
    }
    if (this.shadow) this.shadow.setPosition(this.x, this.y + 13);
  }

  update(time, delta) {
    this.stateTimer -= delta;

    if (this.statusIcon.visible) {
      const isFeedbackPlaying = this.feedbackTween && this.feedbackTween.isPlaying();
      if (!isFeedbackPlaying) this.statusIcon.setPosition(this.x, this.y - 25);
    }
    if (this.traitIcon) this.traitIcon.setPosition(this.x + 10, this.y - 15);

    switch (this.currentState) {
      case STATE.MOVING: this.updateMoving(delta); break;
      case STATE.WORKING: this.updateWorking(delta); break;
      case STATE.COFFEE: this.updateCoffee(); break;
      case STATE.MEETING: this.updateMeeting(delta); break;
      case STATE.CHAT: this.updateChat(delta); break;
      case STATE.BREAK: this.updateBreak(delta); break;
      case STATE.IDLE:
      default: this.updateIdle(delta); break;
    }
  }

  drain(delta, rate = 0.005) {
    this.energy = Math.max(0, this.energy - delta * rate);
  }

  updateIdle(delta) {
    this.drain(delta);
    if (this.stateTimer <= 0) this.decideNextAction();
  }

  updateMoving(delta) {
    this.drain(delta);
    this._footprintTimer += delta;
    if (this._footprintTimer > 250) {
      this._footprintTimer = 0;
      this.scene.addFootprint(this.x, this.y + 12);
    }
    this.followPath();
  }

  updateWorking(delta) {
    this.drain(delta);
    if (Math.random() < 0.05) this.spawnWorkParticles();
    if (this.role === 'dev' && Phaser.Math.RND.frac() < 0.01) {
      this.scene.createCodeBits(this.x, this.y - 10);
    }
  }

  updateMeeting(delta) {
    this.drain(delta, 0.002);
    if (Math.random() < 0.008) this.showFeedback('💬');
    // Ends when the scene calls endMeeting() (stateTimer is a safety net)
    if (this.stateTimer <= 0) this.endMeeting();
  }

  updateChat(delta) {
    this.drain(delta, 0.002);
    if (Math.random() < 0.015) this.showFeedback('💬');
    if (this.stateTimer <= 0) {
      this.energy = Math.min(100, this.energy + 10);
      this.currentState = STATE.IDLE;
      this.stateTimer = 800;
    }
  }

  updateBreak(delta) {
    if (Math.random() < 0.01) this.showFeedback('😴');
    if (this.stateTimer <= 0) {
      this.energy = Math.min(100, this.energy + 40);
      this.currentState = STATE.IDLE;
      this.stateTimer = 500;
    }
  }

  spawnWorkParticles() {
    const emitter = this.scene.roleEmitters?.[this.role];
    if (emitter) emitter.explode(2, this.x, this.y - 10);
  }

  startWorkSequence() {
    if (this.workTween) this.workTween.stop();
    const startX = this.x;
    this.workTween = this.scene.tweens.chain({
      targets: this,
      onComplete: () => this.finishTask(),
      tweens: [
        { scaleX: 1.2, scaleY: 0.8, duration: 150, ease: 'Quad.easeOut' },
        {
          angle: { from: -5, to: 5 },
          x: { from: startX - 1, to: startX + 1 },
          duration: 80, yoyo: true, repeat: 10, ease: 'Linear',
        },
        { scaleX: 1, scaleY: 1, angle: 0, x: startX, duration: 200, ease: 'Back.easeOut' },
      ],
    });
  }

  finishTask() {
    this.currentState = STATE.IDLE;
    this.showFeedback('$');
    this.releaseDesk();
    this.stateTimer = 1500;
  }

  updateCoffee() {
    if (this.stateTimer <= 0) {
      this.energy = 100;
      this.currentState = STATE.IDLE;
      this.showFeedback('Refilled!');
      this.stateTimer = 800;
    }
  }

  startPath(path) {
    if (path && path.length > 0) {
      this.path = path;
      this.currentState = STATE.MOVING;
      this.nextPathPoint();
    } else {
      // No path found: fall back to idle so intent doesn't wedge the FSM.
      this.movementIntent = null;
      this.releaseDesk();
      this.currentState = STATE.IDLE;
      this.stateTimer = 1000;
    }
  }

  nextPathPoint() {
    if (this.path.length === 0) {
      this.stopMovement();
      return;
    }
    const nextTile = this.path.shift();
    this.movementTarget.set(nextTile.x * 32 + 16, nextTile.y * 32 + 16);
    const speed = this.role === 'support' ? 150 : 100;
    this.scene.physics.moveTo(this, this.movementTarget.x, this.movementTarget.y, speed);
  }

  followPath() {
    this._tempVec.set(this.x, this.y);
    if (this.movementTarget.distanceSq(this._tempVec) < 16) this.nextPathPoint();
  }

  stopMovement() {
    this.body.reset(this.x, this.y);
    const intent = this.movementIntent;
    this.movementIntent = null;

    if (intent === 'FETCH_COFFEE') {
      this.currentState = STATE.COFFEE;
      this.stateTimer = 5000;
    } else if (intent === 'WORK') {
      this.currentState = STATE.WORKING;
      this.startWorkSequence();
      this.showFeedback(this.role === 'dev' ? '101' : '$');
    } else if (intent === 'MEETING') {
      this.currentState = STATE.MEETING;
      this.stateTimer = 30000; // safety net; scene ends the meeting
    } else if (intent === 'CHAT') {
      this.currentState = STATE.CHAT;
      this.stateTimer = 6000;
    } else if (intent === 'BREAK') {
      this.currentState = STATE.BREAK;
      this.stateTimer = 7000;
    } else {
      this.currentState = STATE.IDLE;
      this.stateTimer = 1000;
    }
  }

  endMeeting() {
    if (this.currentState === STATE.MEETING || this.movementIntent === 'MEETING') {
      this.movementIntent = null;
      this.currentState = STATE.IDLE;
      this.stateTimer = 500;
    }
  }

  showFeedback(text) {
    const colors = {
      $: '#ffff00',
      '???': '#ff4444',
      '☕': '#ffffff',
      'Refilled!': '#ffffff',
      101: '#00ff00',
      '💬': '#9be7ff',
      '😴': '#aaaaff',
      default: '#00ff00',
    };
    const color = colors[text] || colors['default'];

    this.statusIcon.setText(text);
    this.statusIcon.setColor(color);
    this.statusIcon.setVisible(true);
    this.statusIcon.setAlpha(1);
    this.statusIcon.y = this.y - 20;

    if (this.feedbackTween && this.feedbackTween.isPlaying()) this.feedbackTween.stop();
    this.feedbackTween = this.scene.tweens.add({
      targets: this.statusIcon,
      y: this.y - 40,
      alpha: 0,
      duration: 1000,
      onComplete: () => this.statusIcon?.setVisible(false),
    });
  }

  showTraitIcon(text, color) {
    this.traitIcon = this.scene.add
      .text(this.x, this.y, text, {
        fontSize: '12px',
        color,
        stroke: CSS_PALETTE.OUTLINE_DARK,
        strokeThickness: 2,
      })
      .setOrigin(0.5)
      .setDepth(99);
  }

  goTo(gx, gy, intent) {
    this.movementIntent = intent;
    this.scene.requestMove(this, gx, gy);
  }

  decideNextAction() {
    if (this.energy < 30 && this.movementIntent !== 'FETCH_COFFEE') {
      this.showFeedback('☕');
      const c = this.scene.coffeeTile || { x: 23, y: 16 };
      this.goTo(c.x, c.y, 'FETCH_COFFEE');
      return;
    }

    // Occasional couch break when tired-ish
    if (this.energy < 55 && Phaser.Math.RND.frac() < 0.25) {
      const spot = this.scene.getBreakSpot();
      if (spot) { this.goTo(spot.x, spot.y, 'BREAK'); return; }
    }

    // Seek a desk in the role's zone and work there
    if (Phaser.Math.RND.frac() > 0.35) {
      const desk = this.scene.claimDesk(this);
      if (desk) {
        this.desk = desk;
        this.goTo(desk.chairGx, desk.chairGy, 'WORK');
        return;
      }
    }

    // Otherwise wander
    this.currentState = STATE.IDLE;
    this.moveToRandomPoint();
    if (this.role === 'sales' && Phaser.Math.RND.frac() > 0.8) this.showFeedback('$');
  }

  moveToRandomPoint() {
    const gridX = Phaser.Math.Between(1, 23);
    const gridY = Phaser.Math.Between(1, 18);
    this.scene.requestMove(this, gridX, gridY);
  }
}
