/**
 * Minimal zustand-shaped store (getState / setState / subscribe(selector, cb))
 * so MainScene's subscription code stays drop-in compatible with the repo's
 * useGameStore. The AI director is simulated (no API calls).
 */
const state = {
  tick: 0,
  day: 1,
  mood: 85,
  employees: [],
  activeVisitors: [],
  activeEvents: [],
  officeLevel: 1,
  inventory: [],
  decisionHistory: [],
  isRefactoring: false,
  lastDirectorMsg: 'AI director online. Simulated mode.',
};

const subs = [];
function notify() {
  for (const s of subs) {
    const v = s.sel(state);
    if (v !== s.last) { s.last = v; s.cb(v); }
  }
}

export const useGameStore = {
  getState: () => state,
  setState(patch) { Object.assign(state, patch); notify(); },
  subscribe(sel, cb) {
    const s = { sel, cb, last: sel(state) };
    subs.push(s);
    return () => { const i = subs.indexOf(s); if (i >= 0) subs.splice(i, 1); };
  },
};

let nextId = 1;
const TRAITS = ['NORMAL', 'NORMAL', 'NORMAL', '10x_ENGINEER', 'TOXIC', 'JUNIOR'];

export const actions = {
  hire(role, trait) {
    const t = trait || TRAITS[Math.floor(Math.random() * TRAITS.length)];
    const e = { id: nextId++, role, trait: t };
    useGameStore.setState({ employees: [...state.employees, e] });
    return e;
  },
  fireRandom() {
    if (state.employees.length <= 1) return null;
    const i = Math.floor(Math.random() * state.employees.length);
    const gone = state.employees[i];
    useGameStore.setState({
      employees: state.employees.filter((_, k) => k !== i),
      mood: Math.max(0, state.mood - 8),
    });
    return gone;
  },
  startEvent(type, description, ticks = 20, severity = 'HIGH') {
    if (state.activeEvents.some((e) => e.type === type)) return;
    useGameStore.setState({
      activeEvents: [...state.activeEvents, { type, description, timeLeft: ticks, severity }],
      mood: Math.max(0, state.mood + (type === 'PIZZA_PARTY' ? 12 : -10)),
    });
  },
  addVisitor(key) {
    if (!state.activeVisitors.includes(key)) {
      useGameStore.setState({ activeVisitors: [...state.activeVisitors, key] });
    }
  },
  removeVisitor(key) {
    useGameStore.setState({ activeVisitors: state.activeVisitors.filter((v) => v !== key) });
  },
  addInventory(item) {
    if (!state.inventory.includes(item)) {
      useGameStore.setState({ inventory: [...state.inventory, item] });
    }
  },
  recordDecision(action) {
    useGameStore.setState({
      decisionHistory: [...state.decisionHistory, { action, vetoed: false, at: state.day }],
    });
  },
  setDirectorMsg(msg) { useGameStore.setState({ lastDirectorMsg: msg }); },
  nudgeMood(delta) {
    useGameStore.setState({ mood: Math.max(0, Math.min(100, state.mood + delta)) });
  },
  advanceTick() {
    let { tick, day, mood } = state;
    tick += 1;
    if (tick > 60) { tick = 0; day += 1; }
    // Events expire; visitors tied to events leave with them.
    let events = state.activeEvents;
    if (events.length) {
      events = events
        .map((e) => ({ ...e, timeLeft: e.timeLeft - 1 }))
        .filter((e) => e.timeLeft > 0);
    }
    const hadPizza = state.activeEvents.some((e) => e.type === 'PIZZA_PARTY');
    const hasPizza = events.some((e) => e.type === 'PIZZA_PARTY');
    const hadInv = state.activeEvents.some((e) => e.type === 'INVESTOR_VISIT');
    const hasInv = events.some((e) => e.type === 'INVESTOR_VISIT');
    let visitors = state.activeVisitors;
    if (hadPizza && !hasPizza) visitors = visitors.filter((v) => v !== 'pizza_guy');
    if (hadInv && !hasInv) visitors = visitors.filter((v) => v !== 'investors');
    // Mood drifts back toward 85
    mood += (85 - mood) * 0.01;
    useGameStore.setState({ tick, day, mood, activeEvents: events, activeVisitors: visitors });
  },
};
