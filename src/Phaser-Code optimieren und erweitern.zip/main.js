import Phaser from 'phaser';
import PreloadScene from './game/PreloadScene.js';
import MainScene from './game/MainScene.js';

// Mirrors src/game/config.js — drop-in compatible.
new Phaser.Game({
  type: Phaser.AUTO,
  parent: 'game-container',
  width: 800,
  height: 600,
  backgroundColor: '#0d0f18',
  pixelArt: true,
  scale: {
    mode: Phaser.Scale.FIT,
    autoCenter: Phaser.Scale.CENTER_BOTH,
    width: 800,
    height: 600,
  },
  input: { activePointers: 3 },
  scene: [PreloadScene, MainScene],
  physics: { default: 'arcade', arcade: { gravity: { y: 0 }, debug: false } },
  render: { batchSize: 4096 },
});
